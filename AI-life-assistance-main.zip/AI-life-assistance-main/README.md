![artificial intelligence](https://github.com/sailochan19171/AI-life-assistance/assets/117287129/d6605537-1e6d-48dc-87ea-9755cd311be9)
![lochi assistance](https://github.com/sailochan19171/AI-life-assistance/assets/117287129/c5896c4e-ceb1-462b-9740-e72ffd34d9b2)
![artificial-intelligence](https://github.com/sailochan19171/AI-life-assistance/assets/117287129/077d5f6b-5ca0-4d52-afcb-ae9ac5293827)
![artificial intelligence](https://github.com/sailochan19171/AI-life-assistance/assets/117287129/1b92534c-70b7-4419-b643-07ff68c5e7c2)
# AI-life-assistance
AI life Assistance
